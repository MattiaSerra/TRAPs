function [s,e] = ComputeS_s_e(XG,YG,ug,vg)

% Input arguments:
%   XG: x-component of grid points - matrix
%   YG: y-component of grid points - matrix
%   ug: x-component of the velocity field - matrix
%   vg: y-component of the velocity field - matrix


% Output arguments:
%   s: eigenvalues of S - matrix.   The first entry denotes the eigenvalue number, the last two entries the grid position 
%   e: eigenvectors of S - matrix.  The first entry denotes the eigenvector number, the second entry denotes the component (x=1, y=2),
                                    % the last two entries the grid position

% grid points in vector format
xg = XG(1,:);
yg = YG(:,1);

% compute velocity jacobian 
[ux, uy] = gradient(ug,xg,yg);
[vx, vy] = gradient(vg,xg,yg);

% compute the rate of strain tensor (S) entries 
S11 = ux; 
S12 = .5*(uy + vx) ;
S21 = S12 ;
S22 = vy;

% initialize the eigenvalues and eigenvector matrices 
s = zeros(2,size(ux,1),size(ux,2));   % eigenvalues of S.  The first entry denotes the eigenvalue number, the last two entries the grid position 
e = zeros(2,2,size(ux,1),size(ux,2)); % eigenvectors of S.  The first entry denotes the eigenvector number, the second entry denotes the component (x=1, y=2),
                                      % the last two entries the grid position

% compute the eigenvalues and eigenvectors of S
TrS = S11 + S22;
detS = S11.*S22 - S21.*S12;

% eignvalues 
s(1,:,:)=(TrS-sqrt(TrS.^2-4*detS))/2;
s(2,:,:)=(TrS+sqrt(TrS.^2-4*detS))/2;

% eigenvectors 
e(2,1,:,:) =-S12./sqrt(S12.^2 + (S11 - squeeze(s(2,:,:))).^2);
e(2,2,:,:) =(S11 - squeeze(s(2,:,:)))./sqrt(S12.^2 + (S11 -squeeze(s(2,:,:))).^2);

e(1,1,:,:)=squeeze(e(2,2,:,:));
e(1,2,:,:)=-squeeze(e(2,1,:,:));
end
