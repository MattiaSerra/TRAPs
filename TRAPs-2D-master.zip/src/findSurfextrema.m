function [XXtot,YYtot,flag]=findSurfextrema(XG,YG,p)
% ---------------------- findextrema.m -----------------------
% grid points in vector format
xg = XG(1,:);
yg = YG(:,1);

% compute derivatives in x- and y-directions
[dp_dx,dp_dy] = gradient(p,xg,yg);

% compute second derivatives
[d2p_dx2,d2p_dy_dx] = gradient(dp_dx,xg,yg);
[d2p_dx_dy,d2p_dy2] = gradient(dp_dy,xg,yg);

[XG,YG]=meshgrid(xg,yg);
% contour lines where the first derivatives are zero
cx = contourc(xg,yg,dp_dx,[0 0]);
sx = getcontourlines(cx);

cy = contourc(xg,yg,dp_dy,[0 0]);
sy = getcontourlines(cy);

% Use polyxpoly to find intersections
XXtot=[];YYtot=[];
clear xint yint xintf yintf

ROBUST=0;
for icy =1:length(sy)
for ic = 1:length(sx)
%     funzioneIntersCurves(sy(icy).x, sy(icy).y, sx(ic).x, sx(ic).y,ic)
%     [xint{ic}, yint{ic}] = polyxpoly(sy(icy).x, sy(icy).y, sx(ic).x, sx(ic).y,'unique');
    [xint{ic}, yint{ic}] = intersections(sy(icy).x, sy(icy).y, sx(ic).x, sx(ic).y,ROBUST);
end
xintf = cat(1, xint{:});
yintf = cat(1, yint{:});
XXtot=[XXtot;xintf];
YYtot=[YYtot;yintf];
end

% Check the second derivatives at those intersections-- if
% d2p_dx2 and d2p_dy2 are the same sign and positive then you have a
% minimum, if they are the same sign and negative then you are at a minimum
% and if they have different signs then you are at a saddle point.

d2p_dx2CP=interp2(XG,YG,d2p_dx2,XXtot,YYtot,'cubic',0);
d2p_dy_dxCP=interp2(XG,YG,d2p_dy_dx,XXtot,YYtot,'cubic',0);
d2p_dy2CP=interp2(XG,YG,d2p_dy2,XXtot,YYtot,'cubic',0);
d2p_dx_dyCP=interp2(XG,YG,d2p_dx_dy,XXtot,YYtot,'cubic',0);

DetHess=d2p_dx2CP.*d2p_dy2CP-(d2p_dy_dxCP.*d2p_dx_dyCP);
TrHess=d2p_dx2CP+d2p_dy2CP;

flag = zeros(size(XXtot,1),size(XXtot,2));
flag(DetHess > 0 & TrHess > 0) = 1; % minima
flag(DetHess<0) = 2; % saddle
flag(DetHess > 0 & TrHess < 0) = 3; % maxima

% -------------------- end findextrema.m ---------------------
end