% [pxt,pyt] = TRAPs_process(pxt_raw,pyt_raw,XG,YG,s1,FracAttr)

% Input arguments:
%   pxt_raw: % x component of TRAPs before satisfying the attraction
%   requirements 
%   pyt_raw: % y component of TRAPs before satisfying the attraction
%   requirements 
%   XG: x-component of grid points - matrix
%   YG: y-component of grid points - matrix
%   s1: atrraction rate field
%   FracAttr: minimum required attraction rate as a fraction of attraction
%   at the TRAP core

% Output arguments:
%   pxt: x-coordinates of TRAPs - size: [#points along a TRAP, #TRAPs]. The
%   coordinates with Nan indicate the regions of the tensor lines that do
%   not satisfy the desired attraction properties
%   pyt: y-coordinates of TRAPs - size: [#points along a TRAP, #TRAPs]. The
%   coordinates with Nan indicate the regions of the tensor lines that do
%   not satisfy the desired attraction properties
%--------------------------------------------------------------------------
function [pxt,pyt] = TRAPs_process(pxt_raw,pyt_raw,XG,YG,s1,FracAttr)

% initialize output TRAPs
pxt = pxt_raw;
pyt = pyt_raw;

% index of the TRAP cores
CoreIdx = (size(pxt_raw,1)+1)/2;

 for kk = 1:size(pxt_raw,2)
     s1TRAP = interp2(XG,YG,s1,pxt_raw(:,kk),pyt_raw(:,kk),'spline',0);
     s1Core = s1TRAP(CoreIdx);
     Bool = zeros(size(s1TRAP));
     Bool(s1TRAP>=0) = Bool(s1TRAP>=0) + 1;                                       % Identify the tensor line points that are not attracting 
     Bool(s1TRAP>(1 - FracAttr)*s1Core) = Bool(s1TRAP>(1 - FracAttr)*s1Core) + 1; % Identify the tensor line points that are not attracting enough compared to their attraction at the trap score
     pxt(Bool>0,kk) = nan;
     pyt(Bool>0,kk) = nan;
     
     % Make sure the attraction rate along the trap decreases monotonically 
     [idx,~] = find(isnan(pxt(:,kk)));

         % initialize variables 
         minIdx = 1;
         maxIdx = size(pxt_raw,1);

             if ~isempty (idx)
             DidxFromCore = idx - CoreIdx; 
             DidxFromCorePos = DidxFromCore(DidxFromCore>0);
             DidxFromCoreNeg = DidxFromCore(DidxFromCore<0);
                  if ~isempty(DidxFromCorePos)
                        maxIdx = min(DidxFromCorePos) + CoreIdx; % find the first index on the upper branch 
                 end
                  if ~isempty(DidxFromCorePos)
                        minIdx = max(DidxFromCoreNeg) + CoreIdx; % find the first index on the lower branch 
                 end
              end

        % Keep the tensor line portion that has enough normal attraction
        % and whose attraction rate decreases monotonically from the TRAP
        % core
         pxt(1:minIdx,kk) = nan; pxt(maxIdx:end,kk) = nan;
         pyt(1:minIdx,kk) = nan; pyt(maxIdx:end,kk) = nan;

end


 
