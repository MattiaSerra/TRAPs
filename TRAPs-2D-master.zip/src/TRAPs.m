% function [pxt,pyt] = TRAPs(xTC,yTC,ArcLength,XG,YG,e,mode,options)

% Input arguments:
%   xTC: x-component trap cores - vector
%   yTC: y-component trap cores - vector
%   ArcLength: % parameterization of \lambda lines: linspace(0,arclength,NumPointsOnCurve)
%   XG: x-component of grid points - matrix
%   YG: y-component of grid points - matrix
%   e: eigenvector fields of the rate of strain tensor 
%   mode: Processor modes: "serial" OR "parallel"
%   options: ODE solver options

% Output arguments:
%   pxt: x-coordinates of TRAPs - size: [#points along a TRAP, #TRAPs]
%   pyt: y-coordinates of TRAPs - size: [#points along a TRAP, #TRAPs]
%--------------------------------------------------------------------------
function [pxt,pyt] = TRAPs(xTC,yTC,ArcLength,XG,YG,e,mode,options)

  % Compute upper branch of the trap (for yTRAP >= yTRAPcore)
    sgn = 1;                    
    [pxt_up,pyt_up] = TensorLine(xTC,yTC,ArcLength,XG,YG,e,sgn,mode,options);

  % Compute lower branch of the trap (for yTRAP < yTRAPcore)
    sgn = -1;
    [pxt_dw,pyt_dw] = TensorLine(xTC,yTC,ArcLength,XG,YG,e,sgn,mode,options);

  % Merge branches of the trap
    pxt = [flipud(pxt_dw(2:end,:));pxt_up];
    pyt = [flipud(pyt_dw(2:end,:));pyt_up];

end
