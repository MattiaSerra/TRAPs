% function [pxt,pyt] = TensorLine(xTC,yTC,ArcLength,XG,YG,e,sgn,mode,options);
                       
% Input arguments:
%   xTC: x-component trap cores - vector
%   yTC: y-component trap cores - vector
%   ArcLength: % parameterization of \lambda lines: linspace(0,arclength,NumPointsOnCurve)
%   XG: x-component of grid points - matrix
%   YG: y-component of grid points - matrix
%   e: eigenvector fields of the rate of strain tensor 
%   mode: Processor modes: "serial" OR "parallel"
%   options: ODE solver options

% Output arguments:
%   pxt: x-coordinates of upper or lower TRAPs branches - size: [#.5*points along a TRAP, #TRAPs]
%   pyt: y-coordinates of upper or lower TRAPs branches - size: [#.5*points along a TRAP, #TRAPs]
%--------------------------------------------------------------------------                                
function [pxt,pyt] = TensorLine(xTC,yTC,ArcLength,xi,yi,e,sgn,mode,options)
    Np = numel(xTC);   % number of TRAPs
    %% Checks:
%     if Np<10;   mode = 'serial';   end;
    xTC = reshape(xTC,[],1);
    yTC = reshape(yTC,[],1);
    %%
    if strcmp(mode,'serial')
        [pxt,pyt] = e_tracing(xTC,yTC,ArcLength,xi,yi,e,sgn,options);                    
    elseif strcmp(mode,'parallel')
%       cpu_num = min(28,Np);
        cpu_num = min(feature('numCores'),Np); 
        id = ceil( linspace(0,Np,cpu_num+1) );
        %% Opening MATLAB Pool
        poolobj = gcp('nocreate'); % If no pool, do not create new one.
        if isempty(poolobj)                                          % if parpool is not open
            parpool('local',cpu_num)
        elseif (~isempty(poolobj)) && (poolobj.NumWorkers~=cpu_num)  % if parpool is not consistent with cpu_num
            delete(gcp)
            parpool('local',cpu_num)
        end
        spmd
            Range = id(labindex)+1:id(labindex+1);
            [pxt,pyt] = e_tracing(xTC(Range),yTC(Range),ArcLength,xi,yi,e,sgn,options);                     
        end
        pxt = cat(2,pxt{:});  
        pyt = cat(2,pyt{:});  
    else
        error('The computational mode is not defined. Choose between "serial" OR "parallel".');
    end
    
end

