% [pxt,pyt] = e_tracing(x0,y0,ArcLength,xi,yi,e,sgn,options)

% Input arguments:
%   xTC: x-component trap cores - vector
%   yTC: y-component trap cores - vector
%   ArcLength: % parameterization of \lambda lines: linspace(0,arclength,NumPointsOnCurve)
%   XG: x-component of grid points - matrix
%   YG: y-component of grid points - matrix
%   sgn = 1 --> Compute the branch of TRAPs with y-coordnates higher than y
%   at the core; (-1) for the lower branch
%   e: eigenvector fields of the rate of strain tensor 
%   options: ODE solver options

% Output arguments:
%   pxt: x-coordinates of upper or lower TRAPs branches - size: [#.5*points along a TRAP, #TRAPs]
%   pyt: y-coordinates of upper or lower TRAPs branches - size: [#.5*points along a TRAP, #TRAPs]
%--------------------------------------------------------------------------
function [pxt,pyt] = e_tracing(xTC,yTC,ArcLength,XG,YG,e,sgn,options)
[m,n] = size(XG);
Np = numel(xTC);
nn=0;
x = XG(1,:)';     dx = abs( x(2)-x(1) );
y = YG(:,1);      dy = abs( y(2)-y(1) );

Xmin = min(x);    Ymin = min(y);
Xmax = max(x);    Ymax = max(y);

%% -- e2 vector field
e2x = squeeze(e(2,1,:,:)); 
e2y = squeeze(e(2,2,:,:));

e2x( imag(e2x)~=0 ) = NaN;
e2y( imag(e2y)~=0 ) = NaN;

[e2x_b, e2y_b] = SmoothVectorField(xTC,yTC);

%-- For sgn>0 --> Compute the branch of TRAPs with y-coordnates higher than y at the core
y_pos = sgn*[0;1];
sgn_0  = sign( y_pos(1).*e2x_b + y_pos(2).*e2y_b );
e2x_b = sgn_0.*e2x_b;   e2y_b = sgn_0.*e2y_b;

[~,F] = ode113(@fun,ArcLength,[xTC(:);yTC(:)],options);
pxt = F(:,1:end/2);
pyt = F(:,end/2+1:end);

 %- Freez the particles at the boundary
        pxt = min( pxt ,Xmax );
        pxt = max( pxt ,Xmin );
        pyt = min( pyt ,Ymax );
        pyt = max( pyt ,Ymin );

%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
    function dy = fun(~,y)
        nn=nn+1;
        %- Freez the particles at the boundary
        Bool = 0*y(1:Np,1) + 1;
        Bool(y(1:Np,1)>=Xmax) = Bool(y(1:Np,1)>=Xmax) + 1; Bool(y(1:Np,1)<=Xmin) = Bool(y(1:Np,1)<=Xmin) + 1;
        Bool(y(Np+1:2*Np,1)>=Ymax) = Bool(y(Np+1:2*Np,1)>=Ymax) + 1; Bool(y(Np+1:2*Np,1)<=Ymin) = Bool(y(Np+1:2*Np,1)<=Ymin) + 1;
        Bool(Bool>1) = 0;

        y(1:Np,1)      = min( y(1:Np,1)      ,Xmax );
        y(1:Np,1)      = max( y(1:Np,1)      ,Xmin );
        y(Np+1:2*Np,1) = min( y(Np+1:2*Np,1) ,Ymax );
        y(Np+1:2*Np,1) = max( y(Np+1:2*Np,1) ,Ymin );


        [e2x_c,e2y_c] = SmoothVectorField(y(1:Np),y(Np+1:2*Np));

        sgn_2 = sign( e2x_c.*e2x_b+e2y_c.*e2y_b );

        e2x_c = sgn_2.*e2x_c;
        e2y_c = sgn_2.*e2y_c;

        dy = zeros(2*Np,1);     % a column vector
        dy(1:Np)      = e2x_c;
        dy(Np+1:2*Np) = e2y_c;
        
        dy(isnan(dy)) = 0;

        e2x_b = e2x_c.*Bool;
        e2y_b = e2y_c.*Bool;
    end
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
    function [v1_0,v2_0] = SmoothVectorField(x0,y0)
        %-- Get indices for 4 neighbors
        id1_UL = floor( (y0-Ymin)/dy ) + 1;   
        id2_UL = floor( (x0-Xmin)/dx ) + 1;
        ind_UL = safe_sub2ind([m,n],id1_UL,id2_UL);

        id1_UR = id1_UL;  
        id2_UR = id2_UL+1;
        ind_UR = safe_sub2ind([m,n],id1_UR,id2_UR);

        id1_DL = id1_UL+1;   
        id2_DL = id2_UL;
        ind_DL = safe_sub2ind([m,n],id1_DL,id2_DL);

        id1_DR = id1_UL+1;   
        id2_DR = id2_UL+1;
        ind_DR = safe_sub2ind([m,n],id1_DR,id2_DR);

        %-- Get vector field values for 4 neighbors
        v1_UL = e2x(ind_UL);
        v1_UR = e2x(ind_UR);
        v1_DL = e2x(ind_DL);
        v1_DR = e2x(ind_DR);

        v2_UL = e2y(ind_UL);
        v2_UR = e2y(ind_UR);
        v2_DL = e2y(ind_DL);
        v2_DR = e2y(ind_DR);
        
        %-- Local Smoothing
        sgn_1 = sign( v1_UL.*v1_UR + v2_UL.*v2_UR );
        v1_UR = sgn_1.*v1_UR;
        v2_UR = sgn_1.*v2_UR;

        sgn_1 = sign( v1_UL.*v1_DL + v2_UL.*v2_DL );
        v1_DL = sgn_1.*v1_DL;
        v2_DL = sgn_1.*v2_DL;

        sgn_1 = sign( v1_UL.*v1_DR + v2_UL.*v2_DR );
        v1_DR = sgn_1.*v1_DR;
        v2_DR = sgn_1.*v2_DR;

        %-- Bilinear interpolation
        % Bilinear interpolation for v1
        c1 = ( XG(ind_UR)-x0 )/dx;
        c2 = ( x0-XG(ind_UL) )/dx;
        c3 = ( YG(ind_DL)-y0 )/dy;
        c4 = ( y0-YG(ind_UL) )/dy;

        v1_0 = c3.*( c1.*v1_UL + c2.*v1_UR ) + c4.*( c1.*v1_DL + c2.*v1_DR );

        % Bilinear interpolation for v2
        c1 = ( XG(ind_UR)-x0 )/dx;
        c2 = ( x0-XG(ind_UL) )/dx;
        c3 = ( YG(ind_DL)-y0 )/dy;
        c4 = ( y0-YG(ind_UL) )/dy;

        v2_0 = c3.*( c1.*v2_UL + c2.*v2_UR ) + c4.*( c1.*v2_DL + c2.*v2_DR );
        
        %-- Normalizing v
        norm_v = sqrt( v1_0.^2+v2_0.^2 );
        v1_0 = v1_0./(norm_v+(norm_v==0));
        v2_0 = v2_0./(norm_v+(norm_v==0));

        
%         if any(isnan(v1_0)) || any(isnan(v1_0))
%             error('... NaN values are detected in %d iteration',nn);
%         end
    end
end

function ind = safe_sub2ind(sz, rr, cc)
      rr(rr < 1) = 1;
      rr(rr > sz(1)) = sz(1);
      cc(cc < 1) = 1;
      cc(cc > sz(2)) = sz(2);
      ind = sub2ind(sz, rr, cc);
    end

